self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "012142958383893199121372a68bbedb",
    "url": "/index.html"
  },
  {
    "revision": "e7e65f5bce4e1c3bb19a",
    "url": "/static/css/2.18585a14.chunk.css"
  },
  {
    "revision": "dcb6c768543dbbd83ca1",
    "url": "/static/css/main.63562028.chunk.css"
  },
  {
    "revision": "e7e65f5bce4e1c3bb19a",
    "url": "/static/js/2.56c3a36e.chunk.js"
  },
  {
    "revision": "dcb6c768543dbbd83ca1",
    "url": "/static/js/main.6985e61f.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "7debc97a3ffa0794d80948b29e8d57f0",
    "url": "/static/media/GrafikUsluge.7debc97a.png"
  },
  {
    "revision": "deb4e7b8eb35a54398b81d1bf4219b6f",
    "url": "/static/media/Kasko-osiguranje.deb4e7b8.png"
  },
  {
    "revision": "844960dab979c0147c3a76b1576e2d41",
    "url": "/static/media/Osiguranje-korisnika-kredita.844960da.png"
  },
  {
    "revision": "f7564d806537557b1c600e06e277bac1",
    "url": "/static/media/Putno-zdravstveno-osiguranje.f7564d80.png"
  },
  {
    "revision": "4bcf9b56ac63ad884eee3397a0ff9e8b",
    "url": "/static/media/arrow-right.4bcf9b56.svg"
  },
  {
    "revision": "f1fe09b8a41a223aacc4b41ca4c6a504",
    "url": "/static/media/aura-logo-web.f1fe09b8.svg"
  },
  {
    "revision": "603d2a15601c385aaccfc09ec407dc50",
    "url": "/static/media/automobili.603d2a15.png"
  },
  {
    "revision": "21fc980d99390a5a0606e5f392940148",
    "url": "/static/media/close.21fc980d.svg"
  },
  {
    "revision": "8636de957977dedc67d4472a12cb9084",
    "url": "/static/media/fb.8636de95.svg"
  },
  {
    "revision": "cc5e92b0767b99437ee32d191c9c2342",
    "url": "/static/media/ig.cc5e92b0.svg"
  },
  {
    "revision": "6bcb402bbc2f684fd7fdee3a975f07fc",
    "url": "/static/media/imovina.6bcb402b.png"
  },
  {
    "revision": "6ffd713364ae4adc17131d803f7a7428",
    "url": "/static/media/konstantan-rast.6ffd7133.png"
  },
  {
    "revision": "3077ff468fc213a6c681545c8d7393ed",
    "url": "/static/media/logo-aura-osiguranje.3077ff46.svg"
  },
  {
    "revision": "0b43d0a6985a2ca0d2641ec2ff8e5081",
    "url": "/static/media/mapa-bih.0b43d0a6.png"
  },
  {
    "revision": "b2935c0ca1a8b9cad375ac60f892306b",
    "url": "/static/media/newsletter.b2935c0c.png"
  },
  {
    "revision": "a1cd80651e2dd63eb80f0c28fcca4e76",
    "url": "/static/media/open.a1cd8065.svg"
  },
  {
    "revision": "930b2b83ba448fb6bb77aa2e6c789f17",
    "url": "/static/media/ostalo.930b2b83.png"
  },
  {
    "revision": "76be43d1bc54b32aa1e73745e0e0e72d",
    "url": "/static/media/putovanja.76be43d1.png"
  },
  {
    "revision": "2d77448dd9c2a5db058cad6a5e5d0f67",
    "url": "/static/media/search.2d77448d.svg"
  },
  {
    "revision": "bfea3f497c3d9434b49b75c9414a7bc5",
    "url": "/static/media/search.bfea3f49.svg"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  },
  {
    "revision": "853a1cd71bca19423c90cf1c2d732feb",
    "url": "/static/media/strucan-tim.853a1cd7.png"
  },
  {
    "revision": "2170135e5fe6a726eb4d7215b94cc628",
    "url": "/static/media/unapredjivanje-usluga.2170135e.png"
  },
  {
    "revision": "708888ea2a31c971ac936391ada93f07",
    "url": "/static/media/viber.708888ea.svg"
  },
  {
    "revision": "00c96fb0ec7b51cbc017aded11fab33f",
    "url": "/static/media/yt.00c96fb0.svg"
  },
  {
    "revision": "9fcb8168b208722f6fc369e902ed3041",
    "url": "/static/media/zadovoljni-klijenti.9fcb8168.png"
  }
]);