self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c49d2a79cbc644e1bf88081b15129f99",
    "url": "/index.html"
  },
  {
    "revision": "ab7eaec3cb00ac3624fb",
    "url": "/static/css/2.18585a14.chunk.css"
  },
  {
    "revision": "4f755e9fc11e91e7bfa4",
    "url": "/static/css/main.24152ab7.chunk.css"
  },
  {
    "revision": "ab7eaec3cb00ac3624fb",
    "url": "/static/js/2.fd81218f.chunk.js"
  },
  {
    "revision": "4f755e9fc11e91e7bfa4",
    "url": "/static/js/main.6a563757.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "4bcf9b56ac63ad884eee3397a0ff9e8b",
    "url": "/static/media/arrow-right.4bcf9b56.svg"
  },
  {
    "revision": "ba65a2943e89cf487f70a6f6eb6ac830",
    "url": "/static/media/aura-logo-web.ba65a294.svg"
  },
  {
    "revision": "da3c91d2dd20c6e1f53a3af007036097",
    "url": "/static/media/auris-logo.da3c91d2.svg"
  },
  {
    "revision": "fb3b2a8f06fb43a87d473a89594506ba",
    "url": "/static/media/auto.fb3b2a8f.svg"
  },
  {
    "revision": "727b4edeaf9f4830035f1316bff30392",
    "url": "/static/media/automobili.727b4ede.svg"
  },
  {
    "revision": "5bfba49b28d94e3be62d371f106cafc7",
    "url": "/static/media/autoosiguranje.5bfba49b.jpg"
  },
  {
    "revision": "d8e353249fb506ae9cd88f214b047744",
    "url": "/static/media/bg-home-min.d8e35324.jpg"
  },
  {
    "revision": "12cb3b22cb51dead2c117c7b29092c34",
    "url": "/static/media/check.12cb3b22.svg"
  },
  {
    "revision": "21fc980d99390a5a0606e5f392940148",
    "url": "/static/media/close.21fc980d.svg"
  },
  {
    "revision": "419a18393dea0fc31ae54091f781aacc",
    "url": "/static/media/fb.419a1839.svg"
  },
  {
    "revision": "d926c5cad16fe351af49193c299d19f2",
    "url": "/static/media/fb.d926c5ca.svg"
  },
  {
    "revision": "3465d7dc60db1fac1526564a769b546e",
    "url": "/static/media/ig.3465d7dc.svg"
  },
  {
    "revision": "e7ff1d39aea75378f85b439f7048c8fe",
    "url": "/static/media/ig.e7ff1d39.svg"
  },
  {
    "revision": "03948e4f489efcdd5ef23d589be085d0",
    "url": "/static/media/imovina.03948e4f.svg"
  },
  {
    "revision": "b1b0b6a1ee5bf5a093b98070f5ba95d8",
    "url": "/static/media/imovina.b1b0b6a1.svg"
  },
  {
    "revision": "d9a95e02f8c163ef6ecde7a1ba4db6cb",
    "url": "/static/media/kasko.d9a95e02.svg"
  },
  {
    "revision": "65c60f0dbe25d1df9fcfda535f496ca5",
    "url": "/static/media/konstantan-rast-animated.65c60f0d.svg"
  },
  {
    "revision": "b38c282c6e766afd9397b4aba45e5fce",
    "url": "/static/media/kredit.b38c282c.svg"
  },
  {
    "revision": "3077ff468fc213a6c681545c8d7393ed",
    "url": "/static/media/logo-aura-osiguranje.3077ff46.svg"
  },
  {
    "revision": "4a659aca2c66898e9f0b7af422198df5",
    "url": "/static/media/logo-aura-osiguranje.4a659aca.svg"
  },
  {
    "revision": "fd58b60d4a567e46418977213c54ec2d",
    "url": "/static/media/mapa-pinovi.fd58b60d.svg"
  },
  {
    "revision": "35860bfb307dfca17af15b12a81222b6",
    "url": "/static/media/newsletter.35860bfb.svg"
  },
  {
    "revision": "7528117e677343867029a31a8af3af40",
    "url": "/static/media/nezgoda.7528117e.svg"
  },
  {
    "revision": "a1cd80651e2dd63eb80f0c28fcca4e76",
    "url": "/static/media/open.a1cd8065.svg"
  },
  {
    "revision": "f927624515939117581073fe4b228c48",
    "url": "/static/media/ostalo.f9276245.svg"
  },
  {
    "revision": "1291e6875275d65004c48930e44cf2fe",
    "url": "/static/media/putno.1291e687.svg"
  },
  {
    "revision": "02b3038e980054944fa86ece1a01a658",
    "url": "/static/media/putovanja.02b3038e.svg"
  },
  {
    "revision": "2d77448dd9c2a5db058cad6a5e5d0f67",
    "url": "/static/media/search.2d77448d.svg"
  },
  {
    "revision": "bfea3f497c3d9434b49b75c9414a7bc5",
    "url": "/static/media/search.bfea3f49.svg"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  },
  {
    "revision": "d530a5b3cf57ba688e402f3023b46516",
    "url": "/static/media/strelica-dugme.d530a5b3.svg"
  },
  {
    "revision": "087cf987cd8b8a5f1cd43e7f99ce405f",
    "url": "/static/media/strucan-tim.087cf987.svg"
  },
  {
    "revision": "18eb99f1d0fcf505306947f2962ae847",
    "url": "/static/media/unapredjivanje-usluga.18eb99f1.svg"
  },
  {
    "revision": "708888ea2a31c971ac936391ada93f07",
    "url": "/static/media/viber.708888ea.svg"
  },
  {
    "revision": "aa04a520cbab40c9dfa42f05bbfdeffe",
    "url": "/static/media/viber.aa04a520.svg"
  },
  {
    "revision": "96b56765712ab88a62190e12d10597eb",
    "url": "/static/media/yt.96b56765.svg"
  },
  {
    "revision": "dcf786dfb6f4139ef9166d5805ff6f6a",
    "url": "/static/media/yt.dcf786df.svg"
  },
  {
    "revision": "be96c66de0f3c6ee63776e53571b36e3",
    "url": "/static/media/zadovoljni-klijenti.be96c66d.svg"
  }
]);