self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8bf570d44fc07b320ee486cd62e35a2c",
    "url": "/index.html"
  },
  {
    "revision": "058c509829c66c6b4f05",
    "url": "/static/css/2.18585a14.chunk.css"
  },
  {
    "revision": "89a3c7b839b8354038e2",
    "url": "/static/css/main.d2aa8490.chunk.css"
  },
  {
    "revision": "058c509829c66c6b4f05",
    "url": "/static/js/2.d3750dde.chunk.js"
  },
  {
    "revision": "89a3c7b839b8354038e2",
    "url": "/static/js/main.fce4858e.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "4bcf9b56ac63ad884eee3397a0ff9e8b",
    "url": "/static/media/arrow-right.4bcf9b56.svg"
  },
  {
    "revision": "ba65a2943e89cf487f70a6f6eb6ac830",
    "url": "/static/media/aura-logo-web.ba65a294.svg"
  },
  {
    "revision": "c4ec52fb3926f383f5b7c90408e6091b",
    "url": "/static/media/auto.c4ec52fb.svg"
  },
  {
    "revision": "727b4edeaf9f4830035f1316bff30392",
    "url": "/static/media/automobili.727b4ede.svg"
  },
  {
    "revision": "d8e353249fb506ae9cd88f214b047744",
    "url": "/static/media/bg-home-min.d8e35324.jpg"
  },
  {
    "revision": "21fc980d99390a5a0606e5f392940148",
    "url": "/static/media/close.21fc980d.svg"
  },
  {
    "revision": "419a18393dea0fc31ae54091f781aacc",
    "url": "/static/media/fb.419a1839.svg"
  },
  {
    "revision": "d926c5cad16fe351af49193c299d19f2",
    "url": "/static/media/fb.d926c5ca.svg"
  },
  {
    "revision": "3465d7dc60db1fac1526564a769b546e",
    "url": "/static/media/ig.3465d7dc.svg"
  },
  {
    "revision": "e7ff1d39aea75378f85b439f7048c8fe",
    "url": "/static/media/ig.e7ff1d39.svg"
  },
  {
    "revision": "b1b0b6a1ee5bf5a093b98070f5ba95d8",
    "url": "/static/media/imovina.b1b0b6a1.svg"
  },
  {
    "revision": "e36168eddb9fcc4a93f0b158e798135d",
    "url": "/static/media/imovina.e36168ed.svg"
  },
  {
    "revision": "1dac0273b30e107fb71b856f60c76020",
    "url": "/static/media/kasko.1dac0273.svg"
  },
  {
    "revision": "e78f782b2c93296a17a6f3f03f8f4a6e",
    "url": "/static/media/konstantan-rast-animated.e78f782b.svg"
  },
  {
    "revision": "6d6c820f389bf65579163cad40316642",
    "url": "/static/media/kredit.6d6c820f.svg"
  },
  {
    "revision": "3077ff468fc213a6c681545c8d7393ed",
    "url": "/static/media/logo-aura-osiguranje.3077ff46.svg"
  },
  {
    "revision": "4a659aca2c66898e9f0b7af422198df5",
    "url": "/static/media/logo-aura-osiguranje.4a659aca.svg"
  },
  {
    "revision": "f09f788a83820c88487309cd5eb6cf15",
    "url": "/static/media/mapa-pinovi.f09f788a.svg"
  },
  {
    "revision": "35860bfb307dfca17af15b12a81222b6",
    "url": "/static/media/newsletter.35860bfb.svg"
  },
  {
    "revision": "cabebb68b61c9cc8cf56368430b1106e",
    "url": "/static/media/nezgoda.cabebb68.svg"
  },
  {
    "revision": "a1cd80651e2dd63eb80f0c28fcca4e76",
    "url": "/static/media/open.a1cd8065.svg"
  },
  {
    "revision": "f927624515939117581073fe4b228c48",
    "url": "/static/media/ostalo.f9276245.svg"
  },
  {
    "revision": "f92b82645ff499f0c55771a9c97f208a",
    "url": "/static/media/putno.f92b8264.svg"
  },
  {
    "revision": "02b3038e980054944fa86ece1a01a658",
    "url": "/static/media/putovanja.02b3038e.svg"
  },
  {
    "revision": "2d77448dd9c2a5db058cad6a5e5d0f67",
    "url": "/static/media/search.2d77448d.svg"
  },
  {
    "revision": "bfea3f497c3d9434b49b75c9414a7bc5",
    "url": "/static/media/search.bfea3f49.svg"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  },
  {
    "revision": "d530a5b3cf57ba688e402f3023b46516",
    "url": "/static/media/strelica-dugme.d530a5b3.svg"
  },
  {
    "revision": "c2a3b845e9e1da9cbaf376662eb4f97e",
    "url": "/static/media/strucan-tim.c2a3b845.svg"
  },
  {
    "revision": "651647fe61516c85bbfa028531f9e434",
    "url": "/static/media/unapredjivanje-usluga.651647fe.svg"
  },
  {
    "revision": "708888ea2a31c971ac936391ada93f07",
    "url": "/static/media/viber.708888ea.svg"
  },
  {
    "revision": "aa04a520cbab40c9dfa42f05bbfdeffe",
    "url": "/static/media/viber.aa04a520.svg"
  },
  {
    "revision": "96b56765712ab88a62190e12d10597eb",
    "url": "/static/media/yt.96b56765.svg"
  },
  {
    "revision": "dcf786dfb6f4139ef9166d5805ff6f6a",
    "url": "/static/media/yt.dcf786df.svg"
  },
  {
    "revision": "d1740ee992553b17a25f59364d5dc91f",
    "url": "/static/media/zadovoljni-klijenti.d1740ee9.svg"
  }
]);